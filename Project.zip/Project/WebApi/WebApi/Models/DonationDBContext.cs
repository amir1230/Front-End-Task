﻿namespace WebApi.Models
{
    public class DonationDBContext
    {
    }
}
